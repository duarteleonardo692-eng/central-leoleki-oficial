package com.genymobile.gnirehtet;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.net.LocalServerSocket;
import android.net.LocalSocket;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

/** Conecta a VPN Gnirehtet por um socket local ao PC via Bluetooth RFCOMM SPP.
 * O protocolo é encaminhamento de bytes, sem alteração do conteúdo original. */
public final class BluetoothBridgeService extends Service {
    private static final String TAG = "LeolekiBT";
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final String CHANNEL = "leoleki_bt_channel";
    public static volatile String status = "Desligado";
    private volatile boolean failed;
    private volatile boolean running;
    private BluetoothServerSocket bluetoothServer;
    private BluetoothSocket bluetoothPeer;
    private LocalServerSocket localServer;
    private LocalSocket vpnPeer;
    private Thread worker;

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Internet Bluetooth", NotificationManager.IMPORTANCE_LOW));
        Intent open = new Intent(this, LeolekiActivity.class);
        PendingIntent tap = PendingIntent.getActivity(this, 0, open,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new Notification.Builder(this, CHANNEL)
            .setContentTitle("Leoleki Internet BT")
            .setContentText("Aguardando conexão do computador")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentIntent(tap)
            .build();
        status = "Preparando serviço Bluetooth SPP...";
        failed = false;
        startForeground(1007, notification);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (!running) {
            running = true;
            worker = new Thread(this::serve, "leoleki-rfcomm-server");
            worker.start();
        }
        return START_NOT_STICKY;
    }

    private void serve() {
        try {
            // Mesmo endereço que Gnirehtet espera via adb reverse. Não use adb reverse junto.
            localServer = new LocalServerSocket("gnirehtet");
            while (running) {
                status = "Preparando anúncio do serviço Bluetooth SPP...";
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null || !adapter.isEnabled()) throw new IOException("Bluetooth não está ligado");
                bluetoothServer = adapter.listenUsingRfcommWithServiceRecord("Leoleki Internet BT", SPP);
                // O status de espera só é exibido depois de o socket servidor ser criado.
                status = "Serviço SPP aberto; aguardando conexão do Windows...";
                Log.i(TAG, "Socket RFCOMM criado para UUID " + SPP + "; aguardando Windows");
                bluetoothPeer = bluetoothServer.accept();
                if (!running) break;
                try { bluetoothServer.close(); } catch (IOException ignored) { }
                bluetoothServer = null;
                status = "Windows conectado. Esperando túnel VPN...";
                vpnPeer = localServer.accept();
                status = "Túnel Bluetooth conectado ao aplicativo VPN.";
                Log.i(TAG, "VPN local <-> Bluetooth iniciado");
                try {
                    bridge(vpnPeer.getInputStream(), vpnPeer.getOutputStream(),
                           bluetoothPeer.getInputStream(), bluetoothPeer.getOutputStream());
                } finally {
                    closeSession();
                }
            }
        } catch (SecurityException e) {
            failed = true;
            status = "Falta permissão Bluetooth: " + e.getMessage();
            Log.e(TAG, "Permissão Bluetooth", e);
        } catch (IOException e) {
            if (running) {
                failed = true;
                status = "Erro Bluetooth/túnel: " + e.getMessage();
            }
            Log.e(TAG, "Falha no túnel", e);
        } finally {
            running = false;
            closeSession();
            closeListener();
            stopSelf();
        }
    }

    private void bridge(InputStream fromVpn, OutputStream toVpn,
                        InputStream fromBt, OutputStream toBt) throws IOException {
        Thread uplink = new Thread(() -> copy(fromVpn, toBt), "leoleki-up");
        uplink.setDaemon(true);
        uplink.start();
        try {
            copy(fromBt, toVpn);
        } finally {
            closeSession();
            try { uplink.join(1500); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
    }

    private void copy(InputStream src, OutputStream dst) {
        byte[] buffer = new byte[8192];
        try {
            int n;
            while (running && (n = src.read(buffer)) != -1) {
                dst.write(buffer, 0, n);
            }
        } catch (IOException e) {
            Log.i(TAG, "Lado do túnel encerrado: " + e.getMessage());
        } finally {
            closeSession();
        }
    }

    private void closeSession() {
        LocalSocket local = vpnPeer; vpnPeer = null;
        BluetoothSocket bt = bluetoothPeer; bluetoothPeer = null;
        try { if (local != null) local.close(); } catch (IOException ignored) { }
        try { if (bt != null) bt.close(); } catch (IOException ignored) { }
    }

    private void closeListener() {
        BluetoothServerSocket bt = bluetoothServer; bluetoothServer = null;
        LocalServerSocket local = localServer; localServer = null;
        try { if (bt != null) bt.close(); } catch (IOException ignored) { }
        try { if (local != null) local.close(); } catch (IOException ignored) { }
    }

    @Override public void onDestroy() {
        running = false;
        closeSession();
        closeListener();
        if (worker != null) worker.interrupt();
        // Não apague o diagnóstico de uma falha imediatamente ao encerrar o serviço.
        if (!failed) status = "Desligado";
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
